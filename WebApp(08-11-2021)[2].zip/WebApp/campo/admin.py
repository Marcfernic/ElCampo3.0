from django.contrib import admin
from .models import Producto, Terreno, Venta

# Register your models here.

class VentaInline(admin.TabularInline):
    model = Venta
    
class TerrenoAdmin(admin.ModelAdmin):
    list_display = ('tipo')

class ProductoAdmin(admin.ModelAdmin):
    list_display = ('tipo','kilos')

class VentaAdmin(admin.ModelAdmin):
    list_display = ('id','terreno','producto','kilos','metros')
    inlines = [VentaInline]

admin.site.register(Terreno)
admin.site.register(Producto)
admin.site.register(Venta)