# Import your functions here
import uuid
from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse 

# Create your models here.

class Lugar(models.Model):
    nombre = models.CharField(max_length=100, blank=False, null=False)

    def __str__(self):
        return self.nombre

class Terreno(models.Model):
    tipo = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.tipo

class Producto(models.Model):
    tipo = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.tipo

class Venta(models.Model):
    id = models.IntegerField(primary_key=True, help_text="ID único para este articulo particular")
    terreno = models.ManyToManyField(Terreno, help_text="Seleccione el tipo de terreno que posee; Si no tiene dejalo en blanco",blank=True)
    producto = models.ManyToManyField(Producto, help_text="Seleccione los productos que vende; Si no los tiene no introduzca nada",blank=True)
    kilos = models.IntegerField(blank=True,null=True)
    metros = models.IntegerField(blank=True,null=True)
    usuario = models.ManyToManyField(User)
    imagen = models.ImageField(blank=True, null=True)

    def __str__(self):
        return '%s' % (self.usuario)
    
    def get_delete(self):
        return reverse('user_delete', args=[str(self.usuario.username)])

    def __str__(self):
        return '%s' % (self.id)
    
    

