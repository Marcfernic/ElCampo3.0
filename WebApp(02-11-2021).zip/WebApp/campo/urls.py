from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.index, name='index'), 
    url(r'^ventas/$', views.VentaListView.as_view(), name='ventas'),
    url(r'^venta/(?P<pk>\d+)$', views.VentaDetailView.as_view(), name='venta-detail'),
]

# enlaces administracion cuenta
urlpatterns += [
    url(r'^accounts/login/$', views.Login, name='login'),
    url(r'^accounts/logout/$', views.Logout, name='logout'),
    url(r'^accounts/password_change/$', views.Password_Change, name='password_change'),
    url(r'^accounts/password_change/done/$', views.Password_Change_Done, name='password_change_done'),
    url(r'^accounts/password_reset/$', views.Password_Reset, name='password_reset'),
    url(r'^accounts/password_reset/done/$', views.Password_Reset_Done, name='password_reset_done'),
    url(r'^accounts/reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$', views.Reset, name='password_reset_confirm'),
    url(r'^accounts/reset/done/$', views.Reset_Done, name='password_reset_complete'),
]