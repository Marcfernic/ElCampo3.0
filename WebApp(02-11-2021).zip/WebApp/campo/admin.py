from django.contrib import admin
from .models import Perfil, Producto, Terreno, Venta

# Register your models here.

class VentaInline(admin.TabularInline):
    model = Venta

class PerfilAdmin(admin.ModelAdmin):
    list_display = ('usuario','imagen')
    fields = ['usuario','imagen']
    inlines = [VentaInline]
    
class TerrenoAdmin(admin.ModelAdmin):
    list_display = ('tipo')

class ProductoAdmin(admin.ModelAdmin):
    list_display = ('tipo','kilos')

class VentaAdmin(admin.ModelAdmin):
    list_display = ('id','terreno','producto','kilos')

admin.site.register(Perfil)
admin.site.register(Terreno)
admin.site.register(Producto)
admin.site.register(Venta)