from django.http.response import Http404
from django.shortcuts import render
from .models import Venta, Terreno, Producto, Perfil
from django.conf import settings
import datetime
from django.views import generic

# Create your views here.

def index(request):
    """
    Función vista para la página inicio del sitio.
    """
    # Genera contadores de algunos de los objetos principales
    
    num_ventas=Venta.objects.all().count()
    num_productos=Producto.objects.all().count()
    num_terrenos=Terreno.objects.all().count()
    num_usuarios=Perfil.objects.all().count()
    
    #La fecha de hoy
    hoy=datetime.date.today()

    # Numero de visitas a esta view, como está contado en la variable de sesión.
    num_visitas = request.session.get('num_visitas', 0)
    request.session['num_visitas'] = num_visitas + 1  

    # Renderiza la plantilla HTML index.html con los datos en la variable contexto
    return render(
        request,
        'index.html',
        context={'num_ventas':num_ventas,'num_productos':num_productos,
        'num_terrenos':num_terrenos,'num_usuarios':num_usuarios,'hoy':hoy,
        'num_visitas':num_visitas,
        })

class VentaListView(generic.ListView):
    model = Venta
    paginate_by = 2
    queryset = Venta.objects.all()
    template_name = 'templates/catalog/venta_list.html'  # Specify your own template name/location

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(VentaListView, self).get_context_data(**kwargs)
        # Get the blog from id and add it to the context
        context['some_data'] = 'This is just some data'
        return context

class VentaDetailView(generic.DetailView):
    model = Venta

    def venta_detail_view(request,pk):
        try:
            venta_id=Venta.objects.get(pk=pk)
        except Venta.DoesNotExist:
            raise Http404("venta does not exist")

        #venta_id=get_object_or_404(venta, pk=pk)

        return render(
            request,
            'campo/venta_detail.html',
            context={'venta':venta_id,}
        )

class Login():
    model = Perfil
    def log_in(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/login.html',
            context={'perfil': perfil_id}
        )
class Logout():
    model = Perfil
    def log_out(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/logout.html',
            context={'perfil': perfil_id}
        )
class Password_Change():
    model = Perfil
    def pass_change(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/password_change.html',
            context={'perfil': perfil_id}
        )
class Password_Change_Done():
    model = Perfil
    def word_done(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/password_change_done.html',
            context={'perfil': perfil_id}
        )
class Password_Reset():
    model = Perfil
    def pass_word(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/password_reset.html',
            context={'perfil': perfil_id}
        )
class Password_Reset_Done():
    model = Perfil
    def pw_rd(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/password_reset_done.html',
            context={'perfil': perfil_id}
        )
class Reset():
    model = Perfil
    def re_set(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/reset.html',
            context={'perfil': perfil_id}
        )
class Reset_Done():
    model = Perfil
    def do_none(request,pk):
        try:
            perfil_usuario=Perfil.objects.get(pk=pk)
        except Perfil.DoesNotExist:
            raise Http404("persona does not exist")

        return render(
            request,
            'registration/reset_done.html',
            context={'perfil': perfil_id}
        )