# Import your functions here
import uuid
from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse 

# Create your models here.

class Terreno(models.Model):
    tipo = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.tipo

class Producto(models.Model):
    tipo = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.tipo

class Venta(models.Model):
    id = models.IntegerField(primary_key=True, help_text="ID único para este articulo particular")
    terreno = models.ManyToManyField(Terreno, help_text="Seleccione el tipo de terreno que posee; Si no tiene dejalo en blanco",blank=True)
    producto = models.ManyToManyField(Producto, help_text="Seleccione los productos que vende; Si no los tiene no introduzca nada",blank=True)
    kilos = models.IntegerField(blank=True,null=True)
    metros = models.IntegerField(blank=True,null=True)
    def __str__(self):
        return '%s' % (self.id)

class Perfil(models.Model):
    """
    Modelo que representa una copia específica de un libro (i.e. que puede ser prestado por la biblioteca).
    """

    imagen = models.ImageField(blank=True, null=True)
    usuario = models.OneToOneField(User, primary_key=True, on_delete=models.CASCADE)
    venta = models.ManyToManyField(Venta)

    def __str__(self):
        return '%s' % (self.usuario)


