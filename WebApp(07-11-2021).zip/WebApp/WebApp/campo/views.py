from django.contrib.auth.mixins import LoginRequiredMixin
from django.http.response import Http404
from django.shortcuts import render
from .models import Venta, Terreno, Producto, Perfil, User
from django.conf import settings
import datetime
from django.views import generic
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required, permission_required
# Create your views here.

def index(request):
    """
    Función vista para la página inicio del sitio.
    """
    # Genera contadores de algunos de los objetos principales
    
    num_ventas=Venta.objects.all().count()
    num_productos=Producto.objects.all().count()
    num_terrenos=Terreno.objects.all().count()
    num_usuarios=Perfil.objects.all().count()
    
    #La fecha de hoy
    hoy=datetime.date.today()

    # Numero de visitas a esta view, como está contado en la variable de sesión.
    num_visitas = request.session.get('num_visitas', 0)
    request.session['num_visitas'] = num_visitas + 1  

    # Renderiza la plantilla HTML index.html con los datos en la variable contexto
    return render(
        request,
        'index.html',
        context={'num_ventas':num_ventas,'num_productos':num_productos,
        'num_terrenos':num_terrenos,'num_usuarios':num_usuarios,'hoy':hoy,
        'num_visitas':num_visitas,
        })

class VentaListView(generic.ListView):
    model = Venta
    paginate_by = 2
    queryset = Venta.objects.all()
    template_name = 'templates/catalog/venta_list.html'  # Specify your own template name/location

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(VentaListView, self).get_context_data(**kwargs)
        # Get the blog from id and add it to the context
        context['some_data'] = 'This is just some data'
        return context

class VentaDetailView(generic.DetailView):
    model = Venta

    def venta_detail_view(request,pk):
        try:
            venta_id=Venta.objects.get(pk=pk)
        except Venta.DoesNotExist:
            raise Http404("venta does not exist")

        #venta_id=get_object_or_404(venta, pk=pk)

        return render(
            request,
            'campo/venta_detail.html',
            context={'venta':venta_id,}
        )

class Login(LoginRequiredMixin, generic.View):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'
    success_url=reverse_lazy('index')
    
class Logout(LoginRequiredMixin, generic.View):
    logout_url = '/logout/'
    redirect_field_name = 'redirect_to'

class UserCreate(CreateView):
    model = User
    template_name ='user_form.html'
    fields = ['first_name','last_name','password','username','email']
"""
class UserUpdate(UpdateView):
    model = User
    template_name ='user_update.html'
    fields = ['first_name','last_name','password','username','email']
"""
class MyPerfil(UpdateView):
    model = User
    template_name ='user_update.html'
    fields = ['first_name','last_name','password','username','email']
    success_url=reverse_lazy('index')
"""
class UserDelete(DeleteView):
    model = User
    template_name ='user_confirm_delete.html'
    success_url = reverse_lazy('index')
"""
class UserDelete(DeleteView):
    model = User
    success_url = reverse_lazy('index')