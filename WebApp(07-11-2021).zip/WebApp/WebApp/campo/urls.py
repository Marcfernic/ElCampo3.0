from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.index, name='index'), 
    url(r'^ventas/$', views.VentaListView.as_view(), name='ventas'),
    url(r'^venta/(?P<pk>\d+)$', views.VentaDetailView.as_view(), name='venta-detail'),
]

# enlaces administracion cuenta
urlpatterns += [
    url(r'^accounts/login/$', views.Login.as_view(), name='login'),
    url(r'^accounts/logout/$', views.Logout.as_view(), name='logout'),
]

#enlaces de gestion de existencia de usuario

urlpatterns += [
    url(r'^user/create/$', views.UserCreate.as_view(), name='user_create'),
    url(r'^user/(?P<pk>\d+)/update/$', views.MyPerfil.as_view(), name='my-perfil'),
    url(r'^user/(?P<pk>\d+)/delete/$', views.UserDelete.as_view(), name='user_delete'),
]