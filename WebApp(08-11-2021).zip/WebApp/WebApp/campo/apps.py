from django.apps import AppConfig


class CampoConfig(AppConfig):
    name = 'campo'
